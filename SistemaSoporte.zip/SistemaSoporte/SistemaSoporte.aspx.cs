﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TuProyecto
{
    public partial class SistemaSoporte : Page
    {
      
        protected void AgregarUsuario_Click(object sender, EventArgs e)
        {
     
            Response.Write("<script>alert('Nuevo usuario agregado.');</script>");
        }

   
        protected void EditarUsuario_Click(object sender, EventArgs e)
        {
            string usuarioId = ((Button)sender).CommandArgument;

            Response.Write("<script>alert('Editar usuario con ID: " + usuarioId + "');</script>");
        }


        protected void EliminarUsuario_Click(object sender, EventArgs e)
        {
            string usuarioId = ((Button)sender).CommandArgument;
      
            Response.Write("<script>alert('Usuario con ID: " + usuarioId + " eliminado.');</script>");
        }

        protected void AgregarTecnico_Click(object sender, EventArgs e)
        {
        
            Response.Write("<script>alert('Nuevo técnico agregado.');</script>");
        }

    
        protected void EditarTecnico_Click(object sender, EventArgs e)
        {
            string tecnicoId = ((Button)sender).CommandArgument;
       
            Response.Write("<script>alert('Editar técnico con ID: " + tecnicoId + "');</script>");
        }

        protected void EliminarTecnico_Click(object sender, EventArgs e)
        {
            string tecnicoId = ((Button)sender).CommandArgument;
   
            Response.Write("<script>alert('Técnico con ID: " + tecnicoId + " eliminado.');</script>");

        protected void AgregarEquipo_Click(object sender, EventArgs e)
        {
       
            Response.Write("<script>alert('Nuevo equipo agregado.');</script>");
        }

     
        protected void VerDetalles_Click(object sender, EventArgs e)
        {
            string equipoId = ((Button)sender).CommandArgument;
           
            Response.Write("<script>alert('Detalles del equipo con ID: " + equipoId + "');</script>");
        }
    }
}
